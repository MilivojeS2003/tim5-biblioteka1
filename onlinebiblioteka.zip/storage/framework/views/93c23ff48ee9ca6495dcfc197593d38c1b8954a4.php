
<?php $__env->startSection('content'); ?>
     <section class="w-screen h-screen pl-[80px] pb-2 text-gray-700">
            
            <div class="heading">
                <div class="flex flex-row justify-between border-b-[1px] border-[#e4dfdf]">
                    <div class="py-[10px] flex flex-row">
                        <div class="w-[77px] pl-[30px]">
                            <img src="img/tomsojer.jpg" alt="">
                        </div>
                        <div class="pl-[15px]  flex flex-col">
                            <div>
                                <h1>
                                    <?php echo e($knjiga->Naslov); ?>

                                </h1>
                            </div>
                            <div>
                                <nav class="w-full rounded">
                                    <ol class="flex list-reset">
                                        <li>
                                            <a href="<?php echo e(route('knjiga.index')); ?>" class="text-[#2196f3] hover:text-blue-600">
                                                Evidencija knjiga
                                            </a>
                                        </li>
                                        <li>
                                            <span class="mx-2">/</span>
                                        </li>
                                        <li>
                                            <a href="#"
                                                class="text-[#2196f3] hover:text-blue-600">
                                                KNJIGA-<?php echo e($knjiga->id); ?>

                                            </a>
                                        </li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                    <div class="pt-[24px] mr-[30px]">
                        <a href="<?php echo e(route('knjiga.otpis',$knjiga)); ?>" class="inline hover:text-blue-600">
                            <i class="fas fa-level-up-alt mr-[3px]"></i>
                            Otpisi knjigu
                        </a>
                        <a href="<?php echo e(route('knjiga.izdavanje',$knjiga)); ?>" class="inline hover:text-blue-600 ml-[20px] pr-[10px]">
                            <i class="far fa-hand-scissors mr-[3px]"></i>
                            Izdaj knjigu
                        </a>
                        <a href="<?php echo e(route('knjiga.vracanje',$knjiga)); ?>" class="hover:text-blue-600 inline ml-[20px] pr-[10px]">
                            <i class="fas fa-redo-alt mr-[3px] "></i>
                            Vrati knjigu
                        </a>
                        <a href="<?php echo e(route('knjiga.rezervacija',$knjiga)); ?>" class="hover:text-blue-600 inline ml-[20px] pr-[10px]">
                            <i class="far fa-calendar-check mr-[3px] "></i>
                            Rezervisi knjigu
                        </a>
                        <p class="inline cursor-pointer text-[25px] py-[10px] pl-[30px] border-l-[1px] border-[#e4dfdf] dotsKnjigaOsnovniDetalji hover:text-[#606FC7]">
                            <i
                                class="fas fa-ellipsis-v"></i>
                        </p>
                        <div
                            class="z-10 hidden transition-all duration-300 origin-top-right transform scale-95 -translate-y-2 dropdown-knjiga-osnovni-detalji">
                            <div class="absolute right-0 w-56 mt-[7px] origin-top-right bg-white border border-gray-200 divide-y divide-gray-100 rounded-md shadow-lg outline-none"
                                aria-labelledby="headlessui-menu-button-1" id="headlessui-menu-items-117" role="menu">
                                <div class="py-1">
                                    <a href="<?php echo e(route('knjiga.edit',$knjiga)); ?>" tabindex="0"
                                        class="flex w-full px-4 py-2 text-sm leading-5 text-left text-gray-700 outline-none hover:text-blue-600"
                                        role="menuitem">
                                        <i class="fas fa-edit mr-[1px] ml-[5px] py-1"></i>
                                        <span class="px-4 py-0">Izmijeni knjigu</span>
                                    </a>
                                    <form action="<?php echo e(route('knjiga.destroy',$knjiga)); ?>" tabindex="0"
                                   method="post" class="flex w-full px-4 py-2 text-sm leading-5 text-left text-gray-700 outline-none hover:text-blue-600"
                                        role="menuitem">
                                        <?php echo csrf_field(); ?> 
                                        <?php echo method_field('DELETE'); ?>
                                   <button type="submit"><i class="fa fa-trash mr-[5px] ml-[5px] py-1"></i>
                                        <span class="px-4 py-0">Izbrisi knjigu</span>
                                        </button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="flex flex-row overflow-auto height-osnovniDetalji">
                <div class="w-[80%]">
                    <div class="border-b-[1px] py-4 text-gray-500 border-[#e4dfdf] pl-[30px]">
                        <a href="<?php echo e(route('knjiga.show',$knjiga->id)); ?>" class="inline active-book-nav hover:text-blue-800">
                            Osnovni detalji
                        </a>
                        <a href="<?php echo e(route('knjiga.spec',$knjiga)); ?>" class="inline ml-[70px] hover:text-blue-800 ">
                            Specifikacija
                        </a>
                        <a href="<?php echo e(route('knjiga.iznajmljena',$knjiga)); ?>" class="inline ml-[70px] hover:text-blue-800">
                            Evidencija iznajmljivanja
                        </a>
                        <a href="evidencijaKnjigaMultimedija.php" class="inline ml-[70px] hover:text-blue-800">
                            Multimedija
                        </a>
                    </div>
                    <div class="">
                        <!-- Space for content -->
                        <div class="pl-[30px] section- mt-[20px]">
                            <div class="flex flex-row justify-between">
                                <div class="mr-[30px]">
                                    <div class="mt-[20px]">
                                        <span class="text-gray-500 text-[14px]">Naziv knjige</span>
                                        <p class="font-medium"><?php echo e($knjiga->Naslov); ?></p>
                                    </div>
                                    <div class="mt-[40px]">
                                        <span class="text-gray-500 text-[14px]">Kategorija</span>
                                        <?php $__currentLoopData = $knjiga->kategorijas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="font-medium"><?php echo e($kategorija->Naziv); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="mt-[40px]">
                                        <span class="text-gray-500 text-[14px]">Zanr</span>
                                        <?php $__currentLoopData = $knjiga->zanrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="font-medium"><?php echo e($kategorija->Naziv); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="mt-[40px]">
                                        <span class="text-gray-500 text-[14px]">Autor/ri</span>
                                        <?php $__currentLoopData = $knjiga->autors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategorija): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="font-medium"><?php echo e($kategorija->ImePrezime); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="mt-[40px]">
                                        <span class="text-gray-500 text-[14px]">Izdavac</span>
                                        <p class="font-medium"><?php echo e($knjiga->izdavac->Naziv); ?></p>
                                    </div>
                                    <div class="mt-[40px]">
                                        <span class="text-gray-500 text-[14px]">Godina izdavanja</span>
                                        <p class="font-medium">
                                        <?php echo e(date('d.m.Y',strtotime($knjiga->DatumIzdavanja))); ?>

                                        </p>
                                    </div>
                                </div>
                                <div class="mr-[70px] mt-[20px] flex flex-col max-w-[600px]">
                                    <div>
                                        <h4 class="text-gray-500 ">
                                            Storyline (Kratki sadrzaj)
                                        </h4>
                                        <p class="addReadMore showlesscontent my-[10px]">
                                            <?php echo $knjiga->Sadrzaj; ?>

                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="min-w-[20%] border-l-[1px] border-[#e4dfdf] ">
                    <div class="border-b-[1px] border-[#e4dfdf]">
                        <div class="ml-[30px] mr-[70px] mt-[20px] flex flex-row justify-between">
                            <div class="text-gray-500 ">
                                <p>Na raspolaganju:</p>
                                <p class="mt-[20px]">Rezervisano:</p>
                                <p class="mt-[20px]">Izdato:</p>
                                <p class="mt-[20px]">U prekoracenju:</p>
                                <p class="mt-[20px]">Ukupna kolicina:</p>
                            </div>
                            <div class="text-center pb-[30px]">
                                <p class=" bg-green-200 text-green-700 rounded-[10px] px-[6px] py-[2px] text-[14px]">
                                <?php echo e($knjiga->UkupnoPrimjeraka
                                -($knjiga->IzdatoPrimjeraka+$knjiga->RezervisanoPrimjeraka)); ?>

                                 primjeraka</p>
                                <a href="<?php echo e(route('knjiga.arezervacije',$knjiga)); ?>"><p
                                    class=" mt-[16px] bg-yellow-200 text-yellow-700 rounded-[10px] px-[6px] py-[2px] text-[14px]">
                                    <?php echo e($knjiga->RezervisanoPrimjeraka); ?> primjeraka</p></a>
                                    <a href="<?php echo e(route('knjiga.iznajmljena',$knjiga)); ?>"><p
                                    class=" mt-[16px] bg-blue-200 text-blue-800 rounded-[10px] px-[6px] py-[2px] text-[14px]">
                                    <?php echo e($knjiga->IzdatoPrimjeraka); ?> primjerka</p></a>
                                    <a href="<?php echo e(route('knjiga.prekoracenje',$knjiga)); ?>">  <p
                                    class=" mt-[16px] bg-red-200 text-red-800 rounded-[10px] px-[6px] py-[2px] text-[14px]">
                                    <?php echo e($knjiga->u_prekoracenju()); ?> primjerka</p></a>
                                <p
                                    class=" mt-[16px] border-[1px] border-green-700 text-green-700 rounded-[10px] px-[6px] py-[2px] text-[14px]">
                                    <?php echo e($knjiga->UkupnoPrimjeraka); ?> primjeraka</p>
                            </div>
                        </div>
                    </div>
                    <div class="mt-[40px] mx-[30px]">
                    
                    <?php $__currentLoopData = $knjiga->izdate3(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-[40px] flex flex-col max-w-[304px]">
                            <div class="text-gray-500 ">
                                <p class="inline uppercase">
                                    Izdavanja knjige
                                </p>
                                <span>
                                &nbsp; - &nbsp; prije  <?php if($i->zadrzavanje($i->izdavanje_id)['check']==true): ?>
                               <?php if(substr($i->zadrzavanje($i->izdavanje_id)['mjeseci'],0,1)!="0"): ?>
                               <?php if(substr($i->zadrzavanje($i->izdavanje_id)['nedjelja'],1,1)!="0"): ?>
                               <?php echo e($i->zadrzavanje($i->izdavanje_id)['mjeseci']); ?>

                              
                               <?php else: ?> 
                               <?php echo e($i->zadrzavanje($i->izdavanje_id)['mjeseci']); ?>

        
                               <?php endif; ?>
                               <?php else: ?> 
                               <?php if(substr($i->zadrzavanje($i->izdavanje_id)['nedjelja'],1,1)!="0"): ?>
                               <?php echo e($i->zadrzavanje($i->izdavanje_id)['nedjelja']); ?>

                                <?php else: ?> 
                               <?php echo e(substr($i->zadrzavanje($i->izdavanje_id)['danan'],3)); ?>

                               <?php endif; ?>
                               <?php endif; ?>
                               <?php else: ?>

                                <?php if($i->zadrzavanje($i->izdavanje_id)['dana']): ?>
                                par trenutaka
                                <?php endif; ?>

                               <?php endif; ?>
                                </span>
                            </div>
                            <div>
                                <p>
                                    <a href="<?php echo e(route('bibliotekar.show',$i->izdata_od->id)); ?>" class="text-[#2196f3] hover:text-blue-600">
                                        <?php echo e($i->izdata_od->ImePrezime); ?>

                                    </a>
                                    je izdala(o) knjigu
                                    <a href="<?php echo e(route('ucenik.show',$i->izdata_za->id)); ?>" class="text-[#2196f3] hover:text-blue-600">
                                        <?php echo e($i->izdata_za->ImePrezime); ?>

                                    </a>
                                    dana
                                    <span class="font-medium">
                                        <?php echo e(date('d.m.Y',strtotime($i->datumizdavanja))); ?>

                                    </span>
                                </p>
                            </div>
                            <div>
                                <a href="<?php echo e(route('knjiga.izdavanjedetalji',$i)); ?>" class="text-[#2196f3] hover:text-blue-600">
                                    pogledaj detaljnije >>
                                </a>
                            </div>
                        </div>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-[40px]">
                            <a href="<?php echo e(route('dashboard.aktivnosti',$knjiga)); ?>" class="text-[#2196f3] hover:text-blue-600">
                                <i class="fas fa-history"></i> Prikazi sve
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Vlado\Desktop\PROJEKAT_KOPIJA\onlinebiblioteka\resources\views/knjiga/show.blade.php ENDPATH**/ ?>