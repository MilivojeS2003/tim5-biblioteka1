<?php

namespace Database\Factories;

use App\Models\Rezervacijastatu;
use Illuminate\Database\Eloquent\Factories\Factory;

class RezervacijastatuFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Rezervacijastatu::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
