<?php

namespace Database\Factories;

use App\Models\Jezik;
use Illuminate\Database\Eloquent\Factories\Factory;

class JezikFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = Jezik::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            //
        ];
    }
}
