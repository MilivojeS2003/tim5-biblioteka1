<?php

namespace App\Http\Controllers;

use App\Models\Rezervacijastatu;
use Illuminate\Http\Request;

class RezervacijastatuController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Rezervacijastatu  $rezervacijastatu
     * @return \Illuminate\Http\Response
     */
    public function show(Rezervacijastatu $rezervacijastatu)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Rezervacijastatu  $rezervacijastatu
     * @return \Illuminate\Http\Response
     */
    public function edit(Rezervacijastatu $rezervacijastatu)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Rezervacijastatu  $rezervacijastatu
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Rezervacijastatu $rezervacijastatu)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Rezervacijastatu  $rezervacijastatu
     * @return \Illuminate\Http\Response
     */
    public function destroy(Rezervacijastatu $rezervacijastatu)
    {
        //
    }
}
