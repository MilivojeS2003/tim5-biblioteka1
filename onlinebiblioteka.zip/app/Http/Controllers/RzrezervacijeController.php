<?php

namespace App\Http\Controllers;

use App\Models\Rzrezervacije;
use Illuminate\Http\Request;

class RzrezervacijeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Rzrezervacije  $rzrezervacije
     * @return \Illuminate\Http\Response
     */
    public function show(Rzrezervacije $rzrezervacije)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Rzrezervacije  $rzrezervacije
     * @return \Illuminate\Http\Response
     */
    public function edit(Rzrezervacije $rzrezervacije)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Rzrezervacije  $rzrezervacije
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Rzrezervacije $rzrezervacije)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Rzrezervacije  $rzrezervacije
     * @return \Illuminate\Http\Response
     */
    public function destroy(Rzrezervacije $rzrezervacije)
    {
        //
    }
}
