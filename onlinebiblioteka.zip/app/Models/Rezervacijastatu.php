<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rezervacijastatu extends Model
{
    use HasFactory;
    protected $table='rezervacijastatus';
}
